package com.mina.iot;

import java.util.ArrayList;

public class inputData {
    private int PosCar1 = 0, PosCar2 = 0, PosCoin1 = 0, PosCoin2 = 0, PosBin = 0, PosBin2=0;
    private ArrayList<Integer> coinPositions;

    public inputData() {
        coinPositions = new ArrayList<Integer>();
    }

    public inputData(int posCar1, int posCar2, int posBin,int posBin2) {
        PosCar1 = posCar1;
        PosCar2 = posCar2;
        PosBin = posBin;
        PosBin2 = posBin2;
        coinPositions = new ArrayList<Integer>();
    }

    public inputData(int posCar1, int posCar2, int posCoin1, int posCoin2, int posBin, int posBin2) {
        PosCar1 = posCar1;
        PosCar2 = posCar2;
        PosCoin1 = posCoin1;
        PosCoin2 = posCoin2;
        PosBin = posBin;
        PosBin2 = posBin2;
        coinPositions = new ArrayList<Integer>();
        coinPositions.add(posCoin1);
        coinPositions.add(posCoin2);
    }

    public int getPosCar1() {
        return PosCar1;
    }

    public void setPosCar1(int posCar1) {
        PosCar1 = posCar1;
    }

    public int getPosCar2() {
        return PosCar2;
    }

    public void setPosCar2(int posCar2) {
        PosCar2 = posCar2;
    }

    public int getPosCoin1() {
        return PosCoin1;
    }

    public void setPosCoin1(int posCoin1) {
        PosCoin1 = posCoin1;
    }

    public int getPosCoin2() {
        return PosCoin2;
    }

    public void setPosCoin2(int posCoin2) {
        PosCoin2 = posCoin2;
    }

    public int getPosBin() {
        return PosBin;
    }
    public int getPosBin2() {
        return PosBin2;
    }


    public void setPosBin(int posBin) {
        PosBin = posBin;
    }
    public void setPosBin2(int posBin) {
        PosBin2 = posBin;
    }


    public ArrayList<Integer> getCoinPositions() {
        return coinPositions;
    }

    public void setCoinPositions(ArrayList<Integer> coinPositions) {
        this.coinPositions = coinPositions;
    }

}
