package com.mina.iot;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText PosCar1, PosCar2, PosBin,PosBin2, coinPosition;
   //EditText PosCoin1, PosCoin2;
    FloatingActionButton ToFirebaseButton;
    private DatabaseReference databaseReference;
    inputData data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        PosCar1 = findViewById(R.id.PosCar1);
        PosCar2 = findViewById(R.id.PosCar2);
//        PosCoin1 = findViewById(R.id.PosCoin1);
//        PosCoin2 = findViewById(R.id.PosCoin2);
        PosBin = findViewById(R.id.PosBin);
        PosBin2 = findViewById(R.id.PosBin2);

        coinPosition = findViewById(R.id.coinPos);
        ToFirebaseButton = findViewById(R.id.fab);
        FirebaseApp.initializeApp(this);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        data = new inputData();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getValues();
                databaseReference.child("inputDataFromAndroid").setValue(data);

                final Snackbar snackBar = Snackbar.make(view, "Data Inserted.", Snackbar.LENGTH_SHORT);
                snackBar.setAction("Dismiss", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        snackBar.dismiss();
                    }
                });
                snackBar.show();
            }
        });
    }


    private void getValues() {
        data.setPosCar1(PosCar1.getText().toString().length() > 0 ? Integer.parseInt(PosCar1.getText().toString()) : 100);
        data.setPosCar2(PosCar2.getText().toString().length() > 0 ? Integer.parseInt(PosCar2.getText().toString()) : 100);
//        data.setPosCoin1(PosCoin1.getText().toString().length() > 0 ? Integer.parseInt(PosCoin1.getText().toString()) : 0);
//        data.setPosCoin2(PosCoin2.getText().toString().length() > 0 ? Integer.parseInt(PosCoin2.getText().toString()) : 0);
        data.setPosBin(PosBin.getText().toString().length() > 0 ? Integer.parseInt(PosBin.getText().toString()) : 100);
        data.setPosBin2(PosBin2.getText().toString().length() > 0 ? Integer.parseInt(PosBin2.getText().toString()) : 100);
        data.getCoinPositions().add(coinPosition.getText().toString().length() > 0 ? Integer.parseInt(coinPosition.getText().toString()) : 100);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

//    public void coinBtn(View view) {
//        //data.getCoinPositions().add(coinPosition.getText().toString().length() > 0 ? Integer.parseInt(coinPosition.getText().toString()) : 100);
//
//        final Snackbar snackBar = Snackbar.make(view, coinPosition.getText().toString().length() > 0 ? "Coin in position " + coinPosition.getText().toString() + " added." : "No coin position entered, a \"0\" is inserted instead.", Snackbar.LENGTH_SHORT);
//        snackBar.setAction("Dismiss", new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                snackBar.dismiss();
//            }
//        });
//        snackBar.show();
//    }
}
